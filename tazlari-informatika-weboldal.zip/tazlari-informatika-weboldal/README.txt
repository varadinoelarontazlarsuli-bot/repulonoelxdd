TÁZLÁRI INFORMATIKA – WEBOLDALCSOMAG

Fájlok:
- index.html       Kezdőlap
- tortenet.html    Részletes történet
- style.css        Megjelenés és mobilnézet
- script.js        Mobilmenü és évszám

ELŐNÉZET:
Nyisd meg az index.html fájlt egy böngészőben.

KÖZZÉTÉTEL:
A weboldal statikus HTML/CSS/JS, ezért külön szerverprogram nem szükséges.
Feltölthető GitHub Pagesre vagy Cloudflare Pagesre.
Cloudflare Pages esetén a projekt gyökérkönyvtára ez a mappa; build parancs nem szükséges,
a build output directory pedig / (vagy a gyökérmappa).

FONTOS:
A rekord pontos neve, dátuma, hitelesítője és bizonyítéka még nincs megadva.
A szögletes zárójelben lévő mezőket publikálás előtt ellenőrzött adatokkal kell kitölteni
vagy törölni. Ne kerüljön fel kiskorú személyes elérhetősége, lakcíme vagy más érzékeny adata.
Teljes név, fénykép és videó csak a törvényes képviselő hozzájárulásával tehető közzé.

A jelenlegi csomag NEM jelenti azt, hogy a weboldal már él az interneten.
